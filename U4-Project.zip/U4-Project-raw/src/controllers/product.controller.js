const express = require("express");

const router = express.Router();

const products = require("../models/product.model");

router.get("", async (req, res) => {
  try {
    const product = await products.find().lean().exec();

    res.render("products/product", { productList:product });
  } catch (e) {

    res.status(500).send(e.message);

  }
});




module.exports = router;
