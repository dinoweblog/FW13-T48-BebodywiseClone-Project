const mongoose = require("mongoose");

module.exports=()=>{
    // return new mongoose.connect("mongodb://127.0.0.1:27017/unit-4-project")
    return new mongoose.connect("mongodb+srv://srksaroya:masai123@sunilcluster.s9by7.mongodb.net/unit-4-project?retryWrites=true&w=majority")
    //  return new mongoose.connect("mongosh "mongodb+srv://sunilcluster.s9by7.mongodb.net/myFirstDatabase" --username srksaroya")
}